from enum import Enum, unique


class StopStatus(Enum):
    commercial_stop = 0
    operational_stop = 1
    passing = 2


class StationEntryOrExit(Enum):
    entry = 0
    exit = 1


@unique
class TableCellDataType(Enum):
    algorithm_node = 1
    algorithm_train = 2
    duration = 3
    integer = 4
    local_date_time = 5
    string = 6